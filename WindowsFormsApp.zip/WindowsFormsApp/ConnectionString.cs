﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp
{
    class ConnectionString
    {
        public static string connectionString = @"Data Source=LAPTOP-EV312V69;Initial Catalog=ADO_Net_Demo;Integrated Security=True";
    }
}

